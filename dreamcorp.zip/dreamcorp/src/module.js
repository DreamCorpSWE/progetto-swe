import { MetricsPanelCtrl, alertTab } from 'grafana/app/plugins/sdk'; // will be resolved to app/plugins/sdk
import { PanelCtrl } from 'grafana/app/plugins/sdk'; // will be resolved to app/plugins/sdk
//import { GraphElement } from 'grafana/data/plugins/MyGraph/src/graph'; // will be resolved to app/plugins/sdk
//import { GraphCtrl } from 'grafana/data/plugins/MyGraph/src/';

import './css/panel.base.scss';
import './css/panel.dark.scss';
import './css/panel.light.scss';

//import * as BrowserFS from "browserfs";

import {BayesianTab} from './bayesian_tab';

export class Ctrl extends MetricsPanelCtrl {

  constructor($scope, $injector) {

    super($scope, $injector);
    //tutte queste chiamate successive servono per catturare le funzioni di grafana e utilizzarle nello stesso momento
    //è come se ci appoggiassimo alle chiamate del sistema
    this.events.on('render', this.onRender.bind(this));
    this.events.on('data-received', this.onDataReceived.bind(this));
    this.events.on('data-error', this.onDataError.bind(this));
    this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
    this.events.on('init-edit-mode', this.onInitEditMode.bind(this)); //questa è importante: avviene quando l'oggetto entra in modalità modifica

  }

  //definisco le funzioni altrimenti non compila perchè il costruttore ha bisogno di poter fare il binding
  onRender(){}
  onDataReceived(){}
  onDataError(){}
  onInitEditMode() {
    //quando entra in modalità modifica inserisco la mia tab personalizzata con questo metodo ereditato dalla classe "Panel"
    //il title è libero, la posizione è opzionale, mentre il secondo paramentro indica la "tab" che si vuole inserire
    // e come potete vedere è il richiamo della funzione che si trova in "bayesian_tab.js" che esegue l'export della classe
    this.addEditorTab('Bayesian Network', BayesianTab,3);
  }

  //questi sono altri metodi che c'erano già e io li lascio lì per ora
  link(scope, element) {
    this.initStyles();
  }

  initStyles() {
    window.System.import(this.panelPath + 'css/panel.base.css!');
    // Remove next lines if you don't need separate styles for light and dark themes
    if (grafanaBootData.user.lightTheme) {
      window.System.import(this.panelPath + 'css/panel.light.css!');
    } else {
      window.System.import(this.panelPath + 'css/panel.dark.css!');
    }
    // Remove up to here
  }

  get panelPath() {
    if (this._panelPath === undefined) {
      this._panelPath = `/public/plugins/${this.pluginId}/`;
    }
    return this._panelPath;
  }
  
}

Ctrl.templateUrl = 'partials/template.html';

export { Ctrl as PanelCtrl }
