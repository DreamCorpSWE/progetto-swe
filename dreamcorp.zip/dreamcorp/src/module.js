import { MetricsPanelCtrl, alertTab } from 'grafana/app/plugins/sdk'; // will be resolved to app/plugins/sdk
import { PanelCtrl } from 'grafana/app/plugins/sdk'; // will be resolved to app/plugins/sdk
//import { GraphElement } from 'grafana/data/plugins/MyGraph/src/graph'; // will be resolved to app/plugins/sdk

import './css/panel.base.scss';
import '../dist/networks/rete';

import './css/panel.dark.scss';
import './css/panel.light.scss';

// Remove up to here

export class Ctrl extends MetricsPanelCtrl {
  constructor($scope, $injector) {
    let i;
    super($scope, $injector);
    this.events.on('render', this.onRender.bind(this));
    this.events.on('data-received', this.onDataReceived.bind(this));
    this.events.on('data-error', this.onDataError.bind(this));
    this.events.on('data-snapshot-load', this.onDataReceived.bind(this));
    this.events.on('init-edit-mode', this.onInitEditMode.bind(this));

    //creo la rete bayesiana
    this.jsbayes = require('jsbayes');
    this.g = this.jsbayes.newGraph();

    //import json into text variable
    var my_url = 'public/plugins/grafana-plugin-template-webpack/networks/rete.json';
    this.testJsonSave();
    //funzione di import del file json in formato text
    var text = (function () {
      var text = null;
      $.ajax({
        'async': false,
        'global': false,
        'url': my_url,
        'dataType': "text",
        'success': function (data) {
          text = data;
        }
      });
      return text;
    })();
    //parse into json object from text
    var rete = JSON.parse(text);

    this.nodi = []; //array di variabili di nodi logici di jsbayes

    this.nets = []; //nomi delle reti
    this.id_nodes = []; //id dei nodi
    this.nodes = []; //insieme di nodi di una rete
    this.states_nodes = []; //stati dei nodi
    this.threshold_nodes = []; //soglie dei nodi

    this.netPos = null;
    this.nodePos = null;
    this.statePos = null;
    this.thresholdPos = null;
    this.panel.rete_id = null;
    this.panel.node_id = null;
    this.panel.states_node_id = null;
    this.panel.threshold_node_id = null;
    this.associated = false;

    this.nets.push(rete.rete); //per ora un solo valore

    for (i = 0; i<rete.nodi.length; i++){ //per tutti i nodi li creo e li metto i una lista
      this.id_nodes.push(rete.nodi[i].id); //mi salvo l'id del nodo
      this.states_nodes.push(rete.nodi[i].stati); //mi salvo gli stati
      this.threshold_nodes.push(rete.nodi[i].soglie); //mi salvo le soglie
      this.nodi.push(this.g.addNode(this.id_nodes[i],this.states_nodes[i])); //nuovo nodo logico della rete bayesiana
    }

    this.nodes.push(this.id_nodes); //inserisco un array dentro un altro per essere pronto a gestire più reti

    var index, parent_name;

    for (i = 0; i<rete.nodi.length; i++){ //per tutti i nodi aggiungo i genitori
        if(rete.nodi[i].parents !== null) { // se ha almeno un padre
            for (let j = 0; j < rete.nodi[i].parents.length; j++) {

                parent_name = rete.nodi[i].parents[j]; //mi salvo il nome del parent

                for(let k =0;k<rete.nodi.length;k++){ //per tutti i nodi cerco il parent con quel nome specifico
                    if(parent_name === this.nodi[k].name) index = k;
                }
                //devo passare la variabile stessa non la stringa
                this.nodi[i].addParent(this.nodi[index]);
            }
        }
    }

    //per generare i valori delle cpt a caso
    this.g.reinit()
          .then(function(r) {
              //return this.g.sample(10000); //likelihood weight sampling aka the inference
          });
  }

  testJsonSave(){
    //const editJsonFile = require("edit-json-file");
    //const fs = require('fs');
  }
  onRender(){}
  onDataReceived(){
    console.log("data received");
  }
  onDataError(){}

  onInitEditMode() {
    console.log("onInitEditMode");
    this.addEditorTab('Options', 'public/plugins/grafana-plugin-template-webpack/partials/options.html', 3);
    this.addEditorTab('Alert',alertTab,4);
    this.addEditorTab('Bayesian Network', 'public/plugins/grafana-plugin-template-webpack/partials/bayesian_network.html', 5);

  }
  render(){
    console.log("rendering");
  }

  setNet(net){
    if(net !== null) {
      this.netPos = this.nets.indexOf(net);
      //console.info(this.netPos);
        this.nodePos = null;
        this.statePos = null;
        this.thresholdPos = null;
    }
    else{
      this.netPos = null;
      console.error("Impossible to set net");
    }
  }
  setNode(node){
    if(this.netPos !== null && node !== null) {
      this.nodePos = this.nodes[this.netPos].indexOf(node);
    }
    else{
      this.nodePos = null;
      console.error("Impossible to set node");
    }
  }
  setState(state){

    if(this.nodePos !== null && state !== null){
      this.statePos = this.states_nodes[this.nodePos].indexOf(state);
      this.thresholdPos = this.statePos;
      this.threshold_value = this.threshold_nodes[this.nodePos][this.thresholdPos];
      console.info("setState()");
    }
    else{
      this.statePos = null;
      this.thresholdPos = null;
      console.error("Impossible to set state and threshold");
    }
  }
  setThresholdValue(value){
      //qui modifico le soglie anche nel JSON originale
      if(value)
        console.info("threshold changed to: "+value);
  }

  associate(NodeId){

      console.info("Associated with "+NodeId);
      alert("Associated with " +NodeId);
      this.associated = true;

      this.g.observe(this.nodi[this.nodePos].name,this.states_nodes[this.nodePos][this.statePos]); //osservo il nodo scelto
      this.g.sample(10000);

      this.showProb();


  }
  dissociate(NodeId){
        console.info("Dissociated with "+NodeId);
        alert("Dissociated with " +NodeId);
        this.associated = false;

        this.g.unobserve(this.nodi[this.nodePos].name); //osservo il nodo scelto
        this.g.sample(10000);

        this.showProb();
    }

  showProb(){
      //output probabilità
      for (let x = 0;x<this.nodi.length;x++){
          console.info(this.nodi[x].probs());
      }
  }

  inference(){
      //test inference
      var g2 = this.jsbayes.newGraph();
      var n1 = g2.addNode('n1', ['true', 'false']);
      var n2 = g2.addNode('n2', ['true', 'false']);
      var n3 = g2.addNode('n3', ['true', 'false']);

      n2.addParent(n1);
      n3.addParent(n2);

      //genero le cpt a caso per ora
      g2.reinit()
          .then(function(r) {
              //raccolgo le probabilità generate
              return g2.sample(10000); //likelihood weight sampling aka the inference
          })
          .then(function(r) {
              //do something like console.log(g);

          });

      console.info("Prima di fare observe");
      g2.sample(10000);
      console.info("n1: "+n1.probs());
      console.info("n2: "+n2.probs());
      console.info("n3: "+n3.probs());
      console.info("Observing n1");
      g2.observe('n1', 'true'); //osservare dovrebbe essere inserire nella rete l'informazione certa
      g2.observe('n2', 'true'); //osservare dovrebbe essere inserire nella rete l'informazione certa
      g2.sample(10000);
      console.info("Dopo observe");
      //raccolgo le probabilità generate
      console.info("n1: "+n1.probs()); //questa è sicura a 'true' quindi [1,0]
      console.info("n2: "+n2.probs());
      console.info("n3: "+n3.probs());
  }

  get message(){
    return "DreamCorp";
  }

  link(scope, element) {
    this.initStyles();
  }

  initStyles() {
    window.System.import(this.panelPath + 'css/panel.base.css!');
    // Remove next lines if you don't need separate styles for light and dark themes
    if (grafanaBootData.user.lightTheme) {
      window.System.import(this.panelPath + 'css/panel.light.css!');
    } else {
      window.System.import(this.panelPath + 'css/panel.dark.css!');
    }
    // Remove up to here
  }

  get panelPath() {
    if (this._panelPath === undefined) {
      this._panelPath = `/public/plugins/${this.pluginId}/`;
    }
    return this._panelPath;
  }
  
}

Ctrl.templateUrl = 'partials/template.html';

export { Ctrl as PanelCtrl }
